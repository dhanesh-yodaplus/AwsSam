def lambda_handler(event, context):
    return {
        "statusCode": 200,
        "body": "Demo Lambda executed successfully!"
    }

